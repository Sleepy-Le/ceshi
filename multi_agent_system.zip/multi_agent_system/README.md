# 多 Agent 协同系统

## 项目介绍

该项目是一个简单的多 Agent 协同系统，包含：

- Planner Agent（任务拆解）
- Search Agent（信息检索）
- Execute Agent（任务执行）
- Review Agent（结果审核）

## 安装依赖

```bash
pip install -r requirements.txt
```

## 运行项目

```bash
python main.py
```
