class SearchAgent:
    def search(self, query):
        print("\n[Search Agent] 正在检索信息...")

        fake_result = {
            "query": query,
            "data": "这是搜索到的相关背景信息"
        }

        print(f"[Search Agent] 检索结果: {fake_result}")

        return fake_result
