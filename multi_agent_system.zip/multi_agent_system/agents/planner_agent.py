class PlannerAgent:
    def plan(self, task):
        print("\n[Planner Agent] 正在拆解任务...")

        subtasks = [
            "收集相关信息",
            "执行核心任务",
            "审核结果"
        ]

        print(f"[Planner Agent] 任务拆解完成: {subtasks}")

        return subtasks
