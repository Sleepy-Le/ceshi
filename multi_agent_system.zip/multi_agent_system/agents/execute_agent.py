class ExecuteAgent:
    def execute(self, info):
        print("\n[Execute Agent] 正在执行任务...")

        result = {
            "status": "success",
            "output": f"基于信息 '{info['data']}' 已完成任务执行"
        }

        print(f"[Execute Agent] 执行结果: {result}")

        return result
