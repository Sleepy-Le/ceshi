class ReviewAgent:
    def review(self, result):
        print("\n[Review Agent] 正在审核结果...")

        if result["status"] == "success":
            review_result = {
                "approved": True,
                "comment": "结果通过审核"
            }
        else:
            review_result = {
                "approved": False,
                "comment": "结果存在问题"
            }

        print(f"[Review Agent] 审核结果: {review_result}")

        return review_result
