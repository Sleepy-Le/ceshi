from agents.planner_agent import PlannerAgent
from agents.search_agent import SearchAgent
from agents.execute_agent import ExecuteAgent
from agents.review_agent import ReviewAgent


class MultiAgentSystem:
    def __init__(self):
        self.planner = PlannerAgent()
        self.searcher = SearchAgent()
        self.executor = ExecuteAgent()
        self.reviewer = ReviewAgent()

    def run(self, user_task):
        print("=" * 50)
        print("多 Agent 协同系统启动")
        print("=" * 50)

        subtasks = self.planner.plan(user_task)
        search_result = self.searcher.search(subtasks[0])
        execute_result = self.executor.execute(search_result)
        review_result = self.reviewer.review(execute_result)

        print("\n" + "=" * 50)
        print("最终结果")
        print("=" * 50)

        print(f"用户任务: {user_task}")
        print(f"审核通过: {review_result['approved']}")
        print(f"审核意见: {review_result['comment']}")
        print(f"最终输出: {execute_result['output']}")


if __name__ == "__main__":
    task = "自动生成市场分析报告"

    system = MultiAgentSystem()
    system.run(task)
